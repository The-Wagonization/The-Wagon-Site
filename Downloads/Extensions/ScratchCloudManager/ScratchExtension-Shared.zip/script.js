// Listen for form submission in the popup
document.getElementById('submitButton').addEventListener('click', function() {
  const packetName = document.getElementById('name').value;
  const userName = document.getElementById('user').value;
  const projectId = document.getElementById('project_id').value;

  // Make sure fields are filled
  if (packetName && userName && projectId) {
    // Get the active tab and send a message to content.js
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'handshake',
        packetName: packetName,
        userName: userName,
        projectId: projectId
      }, function(response) {
        console.log('Response from content script:', response);
      });
    });
  } else {
    alert('Please fill out all fields!');
  }
});

// Listen for messages from content.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'updateTextarea') {
    const responseElement = document.getElementById('response');
    if (responseElement) {
      responseElement.value += message.text + '\n';
    }
  }
});

// Listen for "Send Action" form submission
document.getElementById('sendActionSubmitButton').addEventListener('click', function() {
  const variableName = document.getElementById('var_name').value;
  const value = document.getElementById('value').value;
  const userName = document.getElementById('user').value;   // Get username from input
  const projectId = document.getElementById('project_id').value; // Get project ID from input

  // Make sure fields are filled
  if (variableName && value && userName && projectId) {
    // Get the active tab and send a message to content.js
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'sendCloudUpdate',
        variableName: variableName,
        value: value,
        userName: userName,      // Pass username
        projectId: projectId     // Pass project ID
      }, function(response) {
        console.log('Response from content script:', response);
      });
    });
  } else {
    alert('Please fill out all fields!');
  }
});





// Tabs functionality
function openTab(tabId) {
  let tabContents = document.getElementsByClassName("tab-content");
  for (let i = 0; i < tabContents.length; i++) {
    tabContents[i].style.display = "none";
    tabContents[i].classList.remove("active");
  }

  let tabButtons = document.getElementsByClassName("tab-button");
  for (let i = 0; i < tabButtons.length; i++) {
    tabButtons[i].classList.remove("active");
  }

  document.getElementById(tabId).style.display = "block";
  document.getElementById(tabId).classList.add("active");
}

// Add event listeners to the tab buttons
document.getElementById('handshakeTab').addEventListener('click', function() {
  openTab('Handshake');
});
document.getElementById('sendActionTab').addEventListener('click', function() {
  openTab('SendAction');
});

// Show the first tab by default when the page loads
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("Handshake").style.display = "block";
});
